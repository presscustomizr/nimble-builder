=== Nimble Builder ===
Contributors: nikeo
Author URI: https://presscustomizr.com
Plugin URI: https://wordpress.org/plugins/nimble-builder/
Tags: customizer, editor, page builder, drag and drop
Requires at least: 3.4
Tested up to: 4.9.4
Stable tag: 1.0.0-beta-2
License: GPLv3
License URI: https://www.gnu.org/licenses/gpl-3.0.html

Live drag and drop builder for the WordPress Customizer.

== Description ==
**Enhanced Customizer for WordPress.**
Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum.


== Installation ==
1. Install the plugin right from your WordPress admin in plugins > Add New.
1-bis. Download the plugin, unzip the package and upload it to your /wp-content/plugins/ directory
2. Activate the plugin


== Changelog ==
= 1.0.0 : March 1st, 2018 =
* First offical release
